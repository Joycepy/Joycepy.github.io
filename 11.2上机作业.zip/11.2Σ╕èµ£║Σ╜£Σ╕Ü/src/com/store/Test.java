/**
 * 功能介绍
 * 1、进货：如果是店中已经存在的CD库存增加；购入店中没有的CD需要进行标价
 * 2、统计：打印店中库存CD信息、会员信息、资产
 * 3、有人到店：只有会员才能租借或者购买CD(没有CD会给出提示)。如果顾客不是会员，询问顾客是否需要办理会员。会员每次租借或者购买数量都是1张
 * 4、不存在该会员会给出提示
 */

package com.store;

import java.util.Scanner;

public class Test {
	public static void main(String[] args)
	{
		Store s = new Store();
		s.print();
		
		int condition=1;
		while(condition != 5)
		{
			System.out.println("1、进货  2、统计  3、有人到店 4、删除会员  5、退出系统");
			System.out.print("请选择需要进行的操作：");
			Scanner sc = new Scanner(System.in);
			condition = sc.nextInt();
			
			switch(condition)
			{
			case 1:
				s.stock();
				System.out.println("**********************");
				break;
			case 2:
				s.print();
				System.out.println("**********************");
				break;
			case 3:
				System.out.println("请输入您的姓名：");
				String name;
				name = sc.next();
				System.out.println("请输入您的电话号码：");
				String telephone;
				telephone = sc.next();
				Member m0 = new Member(name,telephone);
				
				if(s.isMember(m0))
				{
					int memCondition=1;
					while(memCondition != 3)
					{
						System.out.println("1、租用  2、购买  3、退出");
						System.out.print("请选择：");
						memCondition = sc.nextInt();
						switch(memCondition)
						{
						case 1:
							m0.rent();
							break;
						case 2:
							m0.buy();
							break;
						case 3:
							break;
						default:
							System.out.println("输入的数字错误！");
							break;
						}
					}
				}
				else
				{
					System.out.println("您还不是会员！");
					System.out.println("请问您是否想注册成为会员（需要交¥10注册费）：1、是 2、否");
					int memCondition2 = sc.nextInt();
					switch(memCondition2)
					{
					case 1:
						s.addMember(m0);
						
						int newmemCondition=1;
						while(newmemCondition != 3)
						{
							System.out.println("1、租用  2、购买  3、退出");
							System.out.print("请选择：");
							newmemCondition = sc.nextInt();
							switch(newmemCondition)
							{
							case 1:
								m0.rent();
								break;
							case 2:
								m0.buy();
								break;
							case 3:
								break;
							default:
								System.out.println("输入的数字错误！");
								break;
							}
						}
						break;
						
					case 2:
						System.out.println("欢迎下次光临！");
						break;
					}
					
				}
				System.out.println("**********************");
				break;
				
			case 4:
				s.deleteMember();
				System.out.println("**********************");
				break;
				
			case 5:
				break;
				
				default:
					System.out.println("输入的数字错误！");
					System.out.println("**********************");
					
			}
			
			
		}
		System.out.println("----------商店已关门----------");
		
	}
	
}
