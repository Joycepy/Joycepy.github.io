package com.store;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.store.Member;

public class Store {

	//属性（静态）:库存、资产、最大会员数、存储会员信息的数组
	private static double money;
	private final int MAX_MEMBER = 20;
	static int currMember;
	public static List<CD> cd = new ArrayList<CD>();
	private Member[] m;
	
	
	//构造方法
	Store()
	{
		this.m = new Member[MAX_MEMBER];
		CD c1 = new CD("贝多芬交响曲",6,30,1.5,50);
		CD c2 = new CD("巴赫长笛大键琴奏鸣曲",4,10,1,30);
		CD c3 = new CD("神秘园",5,2,45,75);
		
		cd.add(c1);
		cd.add(c2);
		cd.add(c3);
		
		Member m0 = new Member("章鱼哥","15233221587");
		Member m1 = new Member("派大星","13327894354");
		m[0] = m0;
		m[1] = m1;
		currMember = 2;
	}
	//初始化静态属性
	static {
		money=1000;
		currMember=0;
	}
	
	//get/set方法
	public static double getMoney() {
		return money;
	}

	public static void setMoney(double money) {
		Store.money = money;
	}
	public static List<CD> getCd() {
		return cd;
	}

	//判断是否是会员
	public boolean isMember(Member m0)
	{
		for(int i=0;i<currMember;i++)
		{
			if(m[i].equals(m0))
			{
				return true;
			}
		}
		return false;
	}
	//增加会员
	public void addMember(Member m0)
	{
		if(currMember == MAX_MEMBER)
		{
			System.out.println("本店会员已满！");
			return ;
		}
		m[currMember] = m0;
		currMember++;
		Store.setMoney(Store.getMoney() + 10);
	}
	//删除会员
	public void deleteMember()
	{
		System.out.println("请输入需要删除的会员姓名：");
		String name;
		Scanner sc = new Scanner(System.in);
		name = sc.next();
		System.out.println("请输入需要删除的会员电话号：");
		String telephone;
		telephone = sc.next();
		
		Member m0 = new Member(name,telephone);
		for(int i=0;i<currMember;i++)
		{
			if(m[i].equals(m0))
			{
				for(int j=i+1;j<currMember;j++)
				{
					m[j-1] = m[j];
				}
				currMember--;
				return;
			}
		}
		System.out.println("不存在该会员");
	}
	//进货
	public void stock()
	{
		System.out.println("请输入需要购入的CD名称：");
		String CDname;
		Scanner sc = new Scanner(System.in);
		CDname = sc.next();
		
		System.out.println("请输入需要购入的CD数量：");
		int CDnum;
		CDnum = sc.nextInt();
		
		for(int i=0;i<Store.getCd().size();i++)
		{
			if(Store.getCd().get(i).name.equals(CDname))
			{
				Store.setMoney(Store.getMoney() - (Store.getCd().get(i).stockPrice * CDnum)) ;
				Store.getCd().get(i).stock += CDnum;
				return;
			}
		}
		
		//设置新的CD信息
		System.out.println("----请设置新购入的CD的信息----");
		System.out.println("请设置新购入的CD的租用费用：");
		double newRent = sc.nextDouble();
		System.out.println("请设置新购入的CD的售价：");
		double newPrice = sc.nextDouble();
		
		//随机进货价
		CD c = new CD(CDname,CDnum,Math.random()*100,newRent,newPrice);
		cd.add(c);
		Store.setMoney(Store.getMoney() - c.stockPrice * c.stock) ;
		
	}
	//统计（统计商店的库存、资产、会员信息）
	public void print()
	{
		System.out.println("-----------------------");
		for(int i=0;i<Store.getCd().size();i++)
		{
			Store.getCd().get(i).print();
		}
		System.out.println("-----------------------");
		for(int i=0;i<currMember;i++)
		{
			m[i].print();
		}
		System.out.println("-----------------------");
		System.out.println("当前商店的资产为："+Store.money);
		System.out.println("-----------------------");
	}
	

}