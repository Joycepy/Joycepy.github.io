package com.store;
import java.util.Scanner;
import com.store.Store;

public class Member {
	//属性：name、telephone、rent
	String name;
	String telephone;
	
	//构造函数
	Member(){}
	Member(String name,String telephone)
	{
		this.name = name;
		this.telephone = telephone;
	}
	
	//出租
	void rent()
	{
		System.out.println("请选择需要租借的CD：");
		String rentName;
		Scanner sc = new Scanner(System.in);
		rentName = sc.next();
		
		System.out.println("请选择需要租借的天数：");
		int rentDay = sc.nextInt();
		
		//对应CD类对象
		for(int i=0;i<Store.getCd().size();i++)
		{
			if(Store.getCd().get(i).name.equals(rentName))
			{
				double addMoney = Store.getCd().get(i).rentPrice * rentDay;
				addMoney += Store.getMoney();
				Store.setMoney(addMoney);
				
				Store.getCd().get(i).subStock();
				return;
			}
		}
		System.out.println("没有您需要的CD!");
		
	}
	//购买
	void buy()
	{
		System.out.println("请选择需要购买的CD：");
		String buyName;
		Scanner sc = new Scanner(System.in);
		buyName = sc.next();
		
		for(int i=0;i<Store.getCd().size();i++)
		{
			if(Store.getCd().get(i).name.equals(buyName))
			{
				double addMoney = Store.getCd().get(i).salePrice;
				addMoney += Store.getMoney();
				Store.setMoney(addMoney);
				
				Store.getCd().get(i).subStock();
				return;
			}
		}
		System.out.println("没有您需要的CD!");
	}
	//打印会员信息
	void print()
	{
		System.out.println("会员姓名："+this.name+" "+"电话："+this.telephone);
	}
	boolean equals(Member m)
	{
		if((this.name.equals(m.name))&&(this.telephone.equals(m.telephone)))
			return true;
		return false;
	}
}
