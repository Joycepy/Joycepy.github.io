package com.store;

public class CD {
	//CD名称 库存量、进货价、出租价、售价
	String name;
	int stock;
	double stockPrice;
	double rentPrice;
	double salePrice;
	
	//构造函数
	CD(){}
	CD(String name,int stock,double stockPrice,double rentPrice,double salePrice)
	{
		this.name = name;
		this.stock = stock;
		this.stockPrice = stockPrice;
		this.rentPrice = rentPrice;
		this.salePrice = salePrice;
	}
	
	void subStock()
	{
		this.stock--;
	}
	void print()
	{
		System.out.println("CD名称：《"+this.name+"》  "+"库存："+this.stock+"  "
				+"租用费用："+this.rentPrice+"/天"+"  "+"售价："+this.salePrice);
	}
}
